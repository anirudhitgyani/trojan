
<?php

define( 'dbuser', 'itgyani_itgyani', true );
define( 'dbpassword', 'technofl', true );
define( 'mdb', 'itgyani_itgyani' , true);
define( 'mdbserver', 'mysql.us.cloudlogin.co', true );
define( 'key', 'FV$%^LKOR', true );
/*
define( 'dbuser', 'root', true );
define( 'dbpassword', 'root', true );
define( 'mdb', 'Itgyaniv01', true);
define( 'mdbserver', 'localhost', true );
define( 'key', 'FV$%^LKOR', true );
 */
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

