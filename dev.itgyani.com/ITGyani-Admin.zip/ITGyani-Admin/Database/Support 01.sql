﻿-- CALL PrepareInsertStatement("itgyaniv01","course");
CALL PrepareUpdateStatement("itgyaniv01","course");
CALL ManageAdminSignIn( 'ashish.sharma14@gmail.com' , 'pRjtXyYsn/M=');
 CALL ExecuteUIControls( '101' , '0' , 'ashish.sharma14@gmail.com' , '0');

  CALL ExecuteUIControls( '103' , '' , 'sdfsdf sdfsdf sdfdsfds' , '0');
/*
select GROUP_CONCAT(CONCAT('''' , title , '''' ) SEPARATOR ' as StateName , ') From states

  SELECT 
       CONCAT_WS(',', GROUP_CONCAT( state_id),
                 GROUP_CONCAT( title)) AS all_ids
FROM states;

SELECT group_concat(  '''''''''''' , title , ''''''''''''  , ' As StateName  ', '''''''' , ''''''''  ) FROM states
  */