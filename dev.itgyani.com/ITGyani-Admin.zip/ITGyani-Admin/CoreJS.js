/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
try
{
    // Loading JS
        // Load JS File
    ITGFunStandardLoadExternalJS("JS/jquery-1.11.1.min.js", function(){
    ITGFunStandardLoadExternalJS("JS/modernizr.min.js", function(){    
    ITGFunStandardLoadExternalJS("JS/bootstrap.min.js", function(){
    ITGFunStandardLoadExternalJS("JS/bootbox.min.js", function(){
    ITGFunStandardLoadExternalJS("JS/BrizBStandardJSPageStandardCodeGallery.js", function(){                            
    ITGFunStandardLoadExternalJS("JS/jquery.dataTables.min.js", function(){                            
    ITGFunStandardLoadExternalJS("JS/boxgrid.example2.js", function(){                            
    ITGFunStandardLoadExternalJS("JS/jquery.fadethis.min.js", function(){                            
    ITGFunStandardLoadExternalJS("JS/jquery.transit.min.js", function(){                            
    ITGFunStandardLoadExternalJS("JS/jquery.wheelmenu.js", function(){                            
    ITGFunStandardLoadExternalJS("JS/jquery.blockUI.js", function(){                            
    ITGFunStandardLoadExternalJS("JS/spin.min.js", function(){                            
    ITGFunStandardLoadExternalJS("JS/ladda.min.js", function(){                            
    ITGFunStandardLoadExternalJS("JS/jquery-ui.min.js", function(){                            
    ITGFunStandardLoadExternalJS("JS/dataTables.responsive.min.js", function(){                            
    ITGFunStandardLoadExternalJS("JS/dataTables.jqueryui.min.js", function(){                            
    ITGFunStandardLoadExternalJS("JS/animatedModal.min.js", function(){                            
    ITGFunStandardLoadExternalJS("JS/fancyInput.js", function(){                            
    ITGFunStandardLoadExternalJS("JS/icheck.js", function(){                            
    ITGFunStandardLoadExternalJS("JS/custom.min.js", function(){                            
    ITGFunStandardLoadExternalJS("JS/lavazi.jquery.js", function(){                            
    ITGFunStandardLoadExternalJS("JS/jstree.min.js", function(){ 
    ITGFunStandardLoadExternalJS("JS/jquery.example.js", function(){                            
    ITGFunStandardLoadExternalJS("JS/jquery.filepicker.js", function(){                            
    ITGFunStandardLoadExternalJS("JS/jquery.uploadify.min.js", function(){                            
    ITGFunStandardLoadExternalJS("JS/lobipanel.js", function(){  
    ITGFunStandardLoadExternalJS("JS/chosen.jquery.js", function(){  
    
    }) ;
    }) ;
    }) ;
    }) ;
    }) ;
    }) ;
    }) ;
    }) ;
    }) ;
    }) ;
    }) ;
    }) ;
    }) ;
    }) ;
    }) ;
    }) ;
    }) ;
    }) ;
    }) ;
    }) ;
    }) ;
    }) ;
    }) ;
    }) ;
    }) ;
    }) ;
    }) ;
    
    // Loading CSS
    
            ITGFunStandardLoadExternalCSS("CSS/bootstrap.min.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/bootstrap-theme.min.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/font-awesome.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/jquery.dataTables.min.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/jquery.dataTables_themeroller.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/jquery.datetimepicker.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/red.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/TriangleBreadcrumbs.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/jquery-letterfx.min.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/bootstrap-dropdownhover.min.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/animate.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/chosen.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/bootstrap-dropdownhover.min.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/prism.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/jquery.rippleria.min.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/html5tooltips.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/html5tooltips.animation.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/jquery.floating-social-share.min.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/default.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/climacons.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/component2.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/gridle.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/reset.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/style.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/jquerysctipttop.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/animate.min.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/jquery-ui.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/dataTables.jqueryui.min.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/responsive.jqueryui.min.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/jdb_popup.min.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/animatedModal.min.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/fancyInput.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/iCheckall.css", "css") ; 
            ITGFunStandardLoadExternalCSS("CSS/BrizBVKStandardCSSCore.css", "css") ; 
            ITGFunStandardLoadExternalCSS("CSS/BrizBVKStandardCSSTags.css", "css") ; 
            ITGFunStandardLoadExternalCSS("CSS/lavazi.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/styleLavazi.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/JSTreestyle.min.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/filepicker.default.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/uploadify.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/jquery-ui.min.css", "css") ;
            ITGFunStandardLoadExternalCSS("CSS/lobipanel.css", "css") ;
    
}catch(err){alert(err.message)}
function ITGFunStandardLoadExternalJS(url, callback){
//https://www.nczonline.net/blog/2009/07/28/the-best-way-to-load-external-javascript/
    var ObjStandardExtJS = document.createElement("script")
    ObjStandardExtJS.type = "text/javascript";

    if (ObjStandardExtJS.readyState){  //IE
        ObjStandardExtJS.onreadystatechange = function(){
            if (ObjStandardExtJS.readyState == "loaded" ||
                    ObjStandardExtJS.readyState == "complete"){
                ObjStandardExtJS.onreadystatechange = null;
                callback();
            }
        };
    } else {  //Others
        ObjStandardExtJS.onload = function(){
            callback();
        };
    }

    ObjStandardExtJS.src = url;
    document.getElementsByTagName("head")[0].appendChild(ObjStandardExtJS);
}
function ITGFunStandardLoadExternalCSS(filename, filetype){
    try{
        if (filetype=="js"){ //if filename is a external JavaScript file
            var fileref=document.createElement('ObjStandardExtJS')
            fileref.setAttribute("type","text/javaObjStandardExtJS")
            fileref.setAttribute("src", filename)
        }
        else if (filetype=="css"){ //if filename is an external CSS file
            var fileref=document.createElement("link")
            fileref.setAttribute("rel", "stylesheet")
            fileref.setAttribute("type", "text/css")
            fileref.setAttribute("href", filename)
        }
        if (typeof fileref!="undefined")
            document.getElementsByTagName("head")[0].appendChild(fileref)
    }catch(err){alert(err.message);}
}