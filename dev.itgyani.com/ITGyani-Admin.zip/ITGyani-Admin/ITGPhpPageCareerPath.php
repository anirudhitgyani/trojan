<?php
include_once('ITGHeader.php');
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

?>
<style>

      .filepicker-preview .thumbnail {
        max-width: 100px;
        display: inline-block;
      }
      
      .filepicker-preview .thumbnail img {
        max-width: 100%;
      }
      
    </style>
<script type="text/javascript" src="CoreJS.js"></script>
<link rel="stylesheet" type="text/css" href="CSS/BrizBVKStandardCSSCore.css" />
<link rel="stylesheet" type="text/css" href="CSS/BrizBVKStandardCSSTags.css" />
<script src="js/jquery-1.11.1.min.js"></script> 
<script src="js/bootbox.min.js"></script>
<script src="js/BrizBStandardJSPageStandardCodeGallery.js"></script> 
<script src="JsAjax/ITGStandardJSPageCareerPath.js"></script>   

<button id="ITGBtnAddNew" class="btn btn-danger" style="margin: 2px; " > Add New </button>
<br><br>
<div class="row">
    <div id="IGDivDataEntry">
    <div id="BrizBVKStandardFrmDataEntry" class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ">
        
        <div class="row" id="ITGDivCareerPathName" style=" border-bottom-color:chocolate;border-bottom-style:none;border-bottom-width: 2px;   ">
                    <div class="row" style="padding:2% 0% 1% 0%;font-size:1em;font-weight:bold;   ">
                        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4" style="margin-top:1%; "  >
                            <span class="label label-success" style="padding:2px; ">Career Path Name</span>  
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8" >
                            <input id="ITGTxtCareerPathName"  class="form-control input-sm"  placeholder="Enter Career Path Name ..." type="text" style="min-width:90%; ">
                        </div>
                    </div>
                    <div class="row" style="padding:.5% 0% 1% 0%;font-size:1em;font-weight:bold;   ">
                        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4" style="margin-top:2%; " >
                            <span class="label label-success" style="padding:5px; ">Career Path Description</span>  
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8" >
                            
                            <textarea  class="form-control" id="ITGTxtCareerPathDesc" maxlength="500" rows="4" placeholder="Enter Career Path Description ..."></textarea>
                        </div>
                    </div>
                    <div class="row" style="padding:0% 0% 1% 0%;font-size:1em;font-weight:bold;   ">
                        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4" style="margin-top:2%; " >
                            <span class="label label-success" style="padding:5px; ">Active</span>  
                        </div>
                        <div class="col-xs-12 col-lg-offset-1 col-sm-12 col-md-5 col-lg-5" >                            
                            <label ><input id="ITGChkCourseActive" type="checkbox" class="lbl label-success" style="height:20px;width: 20px; " value=""></label>
                        </div>
                    </div>
            <div class="row">
                <div class="col-lg-offset-5">
                    <button class="btn btn-primary" id="ITGBtnSaveCareerPath" style="margin: 2px; " > Save </button> <button class="btn btn-primary" style="margin: 2px; " > Cancel </button>
                </div>
            </div>
        </div>
    </div>    
    <div id="BrizBVKStandardFrmDataEntry2"  class="col-xs-4 col-sm-4 col-md-4 col-lg-4 pull-right">
        <span class="label label-success" style="padding:5px; ">Career Course</span>  
        <br> <br>
        
        <div id="ITGDivCourseList" class="col-xs-12 col-sm-12 col-md-12 col-lg-12" style="margin-top:2%;height:32%;overflow-y:scroll;   " >
                
         </div>
    </div>
    </div> 
    <div id="ITGGrdCareerPath" class="col-xs-12 col-sm-12 col-md-12 col-lg-12"  >
    <br><br><br><br>        
        <table id="BrizBTblCareerPathDataGrid" class="display nowrap" style="max-height: 50px; min-height: 30%; overflow: auto; position: relative; " cellspacing="0" width="100%">
            <thead>
                <tr style="font-weight:bold;font-size:1.2em;color: #3e1a98;font-family:monospace;border-bottom-style:solid;border-bottom-color:chocolate;border-bottom-width:5px;       ">
                        <th nowrap>Edit</th>
                        <th nowrap>Delete</th>
                        <th nowrap>Career Path</th>
                        <th nowrap>Career Path Description</th>                                                  
                        <th nowrap>Active</th> 
                        <th nowrap>Deleted</th> 
                        <th nowrap>Added By</th>
                        <th nowrap>Added Date</th>
                        <th nowrap>Updated By</th>
                        <th nowrap>Added Date</th>
                    </tr>

                </thead>

        </table>

    </div>
    
    <div class="clearfix" ></div>
</div>


<style type="text/css">
    table.dataTable.stripe tbody tr.odd, table.dataTable.display tbody tr.odd {
        background-color: transparent;
        height: 40px;
    }
    .dataTables_wrapper .dataTables_scroll div.dataTables_scrollBody th, .dataTables_wrapper .dataTables_scroll div.dataTables_scrollBody td {
        vertical-align: middle;
        height: 40px;
    }
    th, td {
    white-space: nowrap;
}
</style>
