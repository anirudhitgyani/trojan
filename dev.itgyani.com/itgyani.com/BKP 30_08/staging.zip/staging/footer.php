<footer id="footer">
<div class="container">
<a href="<?php echo $RootPath; ?>" class="footer-logo"><img src="<?php echo $RootPath; ?>images/logo.png" /></a>
<div class="social-login footer-login text-center"><p>social media links</p><a href="https://www.linkedin.com/company/itgyani"><i class="fa fa-facebook"></i></a><a href="#"><i class="fa fa-twitter"></i></a><a href="https://plus.google.com/u/0/100206678218261154294"><i class="fa fa-google-plus"></i></a><a href="https://www.facebook.com/ITgyani"><i class="fa fa-linkedin"></i></a></div>
<p class="copyright">Copyright @ 2016, All Right Reserved Techno Flair Lab Private Ltd.</p>
</div>
</footer>
<script type="text/javascript">
$( document ).ready(function() {
var $item = $('.home-header'); 
var $wHeight = $(window).height();
$item.height($wHeight); 

 $('#myCarousel').carousel({
	    interval: 10000
	})
});
$(window).on('resize', function (){
  $wHeight = $(window).height();
  $item.height($wHeight);
});
</script>
</body>
</html>
