<?php include('connection.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>IT Gyani</title>
<link href='https://fonts.googleapis.com/css?family=Roboto:400,500,700,300|Roboto+Condensed' rel='stylesheet' type='text/css'>
<link rel="stylesheet" type="text/css" href="<?php echo $RootPath; ?>css/style.css" />
<link rel="stylesheet" type="text/css" href="<?php echo $RootPath; ?>css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="<?php echo $RootPath; ?>css/font-awesome.min.css" />

<script type="text/javascript" src="http://code.jquery.com/jquery-1.11.1.js"></script>
<script type="text/javascript" src="<?php echo $RootPath; ?>js/bootstrap.min.js"></script>
</head>

<body>
<header class="header inner-header">
<div class="container v-center">
<a class="logo" href="<?php echo $RootPath; ?>"><img src="<?php echo $RootPath; ?>images/logo.png" /></a><h1>kick start your career</h1>
<p>Get yout first IT job, guaranteed! Too many confusing options, Which one is yours?</p>
</div>

</header>
