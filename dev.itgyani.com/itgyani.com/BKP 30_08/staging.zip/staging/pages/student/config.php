<?php
$RootPath = "http://itgyani.com/staging/";
$linkedinApiKey = '811tvx3mml8jhd';
$linkedinApiSecret = '5eHtEc1PXiAkOsqK';
$linkedinScope = 'r_basicprofile r_emailaddress';
?>