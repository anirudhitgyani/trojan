<?php include('../../connection.php'); ?>
<?php include('../../header.php'); ?>


<div class="middle-content">

	Your link is active please login click below link
    <a href="<?php echo $RootPath; ?>pages/student" > click </a>

</div>


<?php include('../../footer.php'); ?>