<?php include('../../connection.php'); ?>
<?php include('../../header.php'); ?>
<div class="middle-content">
<div class="pricing-section">
<div class="container">
<div class="black-box-pop">
<div class="price-table">
<h2>The ITGYANI program - Get your first IT job.</h2>
<div class="table-responsive">
<table class="table">
<thead>
<tr>
<td></td><td class="text-center">Free</td><td class="text-center">25000/-</td>
</tr>
</thead>
<tbody>
<tr ><td align="left">Aptitude test</td><td>Yes</td><td>Yes</td></tr>
<tr><td>Foundation course</td><td>Partial</td><td>Yes</td></tr>
<tr><td>Gurantee</td><td>No</td><td>Yes</td></tr>
<tr><td>Counseling</td><td>No</td><td>Yes</td></tr>
<tr><td>Trainer access</td><td>Partial</td><td>Yes</td></tr> 
<tr><td>Psychometric evalution</td><td>No</td><td>Yes</td></tr>
<tr><td>Specialized traning tests</td><td>No</td><td>Yes</td></tr> 
<tr><td>Corporate access</td><td>No</td><td>Yes</td></tr> 
<tr><td>Interview preparation</td><td>No</td><td>Yes</td></tr> 
<tr><td>Live environment training</td><td>No</td><td>Yes</td></tr> 
</tbody>
<tfoot>
<tr>
<td></td><td class="text-center"><a href="#">Join-free</a></td><td class="text-center"><a href="#">Buy Now</a></td>
</tr>
</tfoot>
</table>
</div>
<h2>Know What you love, Love What You Do!</h2>
</div>
<a href="#" class="blue-buttons close-butt">Close</a>
</div>
</div>
</div>

</div>
<?php include('../../footer.php'); ?>